export interface Customer {
  customer_id: string;
  customer_segment: 'Regular' | 'Budget' | 'Premium' | 'Wholesale';
  signup_date: string;
  preferred_channel: 'Mobile App' | 'Online' | 'Partner' | 'In-store';
  city: string;
}

export interface Product {
  product_id: string;
  product_name: string;
  category: 'Beverages' | 'Groceries' | 'Personal Care' | 'Household' | 'Snacks';
  sub_category: string;
  base_price: number;
}

export interface ReturnRecord {
  return_id: string;
  order_id: string;
  return_date: string;
  return_reason: 'Customer Changed Mind' | 'Damaged' | 'Wrong Item' | 'Late Delivery' | 'Quality Issue';
}

export interface Order {
  order_id: string;
  order_date: string;
  store_id: string;
  product_id: string;
  customer_id: string;
  sales_channel: 'Online' | 'Mobile App' | 'In-store' | 'Partner';
  units_sold: number;
  unit_price: number;
  discount_pct: number;
  payment_status: 'Paid' | 'Pending';
  delivery_status: 'Processing' | 'Delivered' | 'Returned';
}

export interface Store {
  store_id: string;
  store_name: string;
  region: 'North' | 'South' | 'East' | 'West' | 'Central';
  city: string;
  store_type: 'Supermarket' | 'Convenience' | 'Express';
}

export const customersRawCSV = `customer_id,customer_segment,signup_date,preferred_channel,city
C-0001,Regular,2026-01-26,Mobile App,Jaipur
C-0002,Budget,2025-07-14,Online,Hyderabad
C-0003,Premium,2025-11-06,Mobile App,Indore
C-0004,Budget,2026-01-09,Partner,Guwahati
C-0005,Budget,2025-07-13,Online,Guwahati
C-0006,Premium,2025-11-18,Mobile App,Mumbai
C-0007,Regular,2025-12-27,Online,Delhi
C-0008,Regular,2026-01-31,Mobile App,Jaipur
C-0009,Regular,2025-02-21,Partner,Chennai
C-0010,Wholesale,2025-11-22,Mobile App,Lucknow
C-0011,Premium,2025-07-01,In-store,Pune
C-0012,Premium,2025-12-26,Online,Mumbai
C-0013,Regular,2025-10-01,In-store,Lucknow
C-0014,Wholesale,2025-07-14,Mobile App,Nagpur
C-0015,Regular,2025-12-17,Mobile App,Bhopal
C-0016,Budget,2025-04-28,Online,Indore
C-0017,Premium,2025-07-25,Mobile App,Jaipur
C-0018,Regular,2025-10-18,Mobile App,Bengaluru
C-0019,Wholesale,2025-07-22,Partner,Lucknow
C-0020,Premium,2025-03-13,In-store,Ahmedabad
C-0021,Premium,2026-01-18,Partner,Nagpur
C-0022,Wholesale,2025-07-05,In-store,Lucknow
C-0023,Wholesale,2025-02-16,Online,Bhopal
C-0024,Budget,2025-03-20,In-store,Indore
C-0025,Wholesale,2025-11-02,Online,Kolkata
C-0026,Wholesale,2025-11-02,Partner,Guwahati
C-0027,Premium,2025-10-11,Online,Pune
C-0028,Budget,2025-12-16,Mobile App,Indore
C-0029,Premium,2025-02-27,Mobile App,Kolkata
C-0030,Regular,2025-08-21,Online,Ahmedabad
C-0031,Premium,2025-09-14,In-store,Guwahati
C-0032,Budget,2025-11-17,Mobile App,Bhopal
C-0033,Regular,2025-03-20,Mobile App,Indore
C-0034,Regular,2025-10-04,Online,Mumbai
C-0035,Premium,2025-09-08,Online,Jaipur
C-0036,Premium,2026-02-18,Mobile App,Bengaluru
C-0037,Budget,2025-05-04,Online,Jaipur
C-0038,Wholesale,2026-02-22,Online,Indore
C-0039,Regular,2025-03-07,Partner,Guwahati
C-0040,Regular,2025-05-16,Partner,Bengaluru
C-0041,Regular,2026-01-01,Mobile App,Kolkata
C-0042,Premium,2025-08-13,Partner,Jaipur
C-0043,Regular,2025-04-26,Online,Hyderabad
C-0044,Budget,2025-10-29,In-store,Mumbai
C-0045,Regular,2025-01-04,Online,Ahmedabad
C-0046,Budget,2025-04-28,Online,Nagpur
C-0047,Budget,2025-06-19,Online,Guwahati
C-0048,Regular,2025-05-23,Partner,Bengaluru
C-0049,Regular,2026-01-06,Partner,Bengaluru
C-0050,Wholesale,2026-02-18,Partner,Bengaluru
C-0051,Budget,2025-02-19,Partner,Hyderabad
C-0052,Wholesale,2025-07-30,Partner,Bhopal
C-0053,Budget,2025-12-11,Online,Delhi
C-0054,Wholesale,2026-01-08,Mobile App,Indore
C-0055,Budget,2025-05-08,In-store,Bengaluru
C-0056,Wholesale,2025-03-13,Partner,Lucknow
C-0057,Premium,2025-08-25,In-store,Bhopal
C-0058,Budget,2025-08-15,Online,Delhi
C-0059,Budget,2025-02-17,In-store,Lucknow
C-0060,Wholesale,2025-09-06,Partner,Bengaluru
C-0061,Wholesale,2025-01-31,In-store,Kolkata
C-0062,Budget,2025-07-19,Mobile App,Nagpur
C-0063,Wholesale,2025-05-27,Partner,Ahmedabad
C-0064,Wholesale,2025-03-21,In-store,Chennai
C-0065,Regular,2025-01-30,Online,Ahmedabad
C-0066,Premium,2025-01-30,Online,Mumbai
C-0067,Wholesale,2025-09-15,In-store,Delhi
C-0068,Budget,2025-04-06,Online,Mumbai
C-0069,Budget,2025-12-12,In-store,Kolkata
C-0070,Budget,2025-10-19,In-store,Mumbai
C-0071,Budget,2025-11-14,Online,Kolkata
C-0072,Premium,2025-05-14,In-store,Pune
C-0073,Premium,2025-05-03,Mobile App,Kolkata
C-0074,Regular,2025-12-10,Mobile App,Bhubaneswar
C-0075,Premium,2026-01-20,Online,Delhi
C-0076,Wholesale,2025-11-15,Online,Jaipur
C-0077,Regular,2025-09-17,Mobile App,Lucknow
C-0078,Premium,2025-02-05,In-store,Hyderabad
C-0079,Premium,2025-03-22,Partner,Bhopal
C-0080,Premium,2025-11-10,Online,Pune`;

export const productsRawCSV = `product_id,product_name,category,sub_category,base_price
P-001,Tea Premium,Beverages,Tea,399
P-002,Cold Brew,Beverages,Cold,149
P-003,Rice 5kg,Groceries,Rice,599
P-004,Cooking Oil,Groceries,Cooking,199
P-005,Herbal Shampoo,Personal Care,Herbal,49
P-006,Face Wash,Personal Care,Face,99
P-007,Detergent,Household,Detergent,399
P-008,Floor Cleaner,Household,Floor,249
P-009,Protein Bar,Snacks,Protein,199
P-010,Trail Mix,Snacks,Trail,99`;

export const returnsRawCSV = `return_id,order_id,return_date,return_reason
R-0001,O-00089,2026-04-20,Customer Changed Mind
R-0002,O-00099,2026-02-06,Damaged
R-0003,O-00103,2026-03-29,Wrong Item
R-0004,O-00030,2026-04-23,Customer Changed Mind
R-0005,O-00128,2026-04-01,Wrong Item
R-0006,O-00017,2026-04-06,Customer Changed Mind
R-0007,O-00234,2026-01-12,Late Delivery
R-0008,O-00026,2026-04-20,Quality Issue
R-0009,O-00185,2026-02-22,Quality Issue
R-0010,O-00102,2026-05-08,Wrong Item
R-0011,O-00141,2026-03-11,Late Delivery
R-0012,O-00189,2026-02-02,Customer Changed Mind
R-0013,O-00238,2026-04-19,Customer Changed Mind
R-0014,O-00259,2026-04-07,Damaged
R-0015,O-00204,2026-05-13,Late Delivery
R-0016,O-00326,2026-03-27,Customer Changed Mind
R-0017,O-00064,2026-02-01,Late Delivery
R-0018,O-00349,2026-04-28,Damaged
R-0019,O-00016,2026-03-14,Damaged
R-0020,O-00124,2026-03-10,Late Delivery
R-0021,O-00191,2026-02-15,Late Delivery
R-0022,O-00251,2026-02-04,Late Delivery
R-0023,O-00305,2026-02-05,Wrong Item
R-0024,O-00229,2026-04-07,Wrong Item
R-0025,O-00091,2026-04-28,Customer Changed Mind
R-0026,O-00243,2026-01-25,Late Delivery
R-0027,O-00301,2026-03-12,Damaged
R-0028,O-00283,2026-01-28,Late Delivery
R-0029,O-00180,2026-02-21,Quality Issue
R-0030,O-00177,2026-03-06,Quality Issue
R-0031,O-00084,2026-03-03,Customer Changed Mind
R-0032,O-00133,2026-04-26,Wrong Item
R-0033,O-00353,2026-03-11,Wrong Item
R-0034,O-00047,2026-02-24,Quality Issue
R-0035,O-00146,2026-02-12,Customer Changed Mind
R-0036,O-00015,2026-02-18,Wrong Item
R-0037,O-00198,2026-05-08,Wrong Item
R-0038,O-00293,2026-03-01,Damaged
R-0039,O-00110,2026-03-12,Wrong Item
R-0040,O-00114,2026-04-23,Customer Changed Mind
R-0041,O-00332,2026-02-17,Late Delivery
R-0042,O-00116,2026-04-16,Wrong Item
R-0043,O-00347,2026-01-18,Wrong Item
R-0044,O-00106,2026-04-07,Quality Issue
R-0045,O-00138,2026-02-11,Late Delivery
R-0046,O-00334,2026-01-10,Customer Changed Mind`;

export const storesRawCSV = `store_id,store_name,region,city,store_type
ST-001,Delhi Superstore,North,Delhi,Supermarket
ST-002,Chennai Mart,South,Chennai,Convenience
ST-003,Guwahati Express,East,Guwahati,Supermarket
ST-004,Mumbai Mart,West,Mumbai,Supermarket
ST-005,Bhopal Superstore,Central,Bhopal,Supermarket
ST-006,Lucknow Superstore,North,Lucknow,Convenience
ST-007,Bengaluru Superstore,South,Bengaluru,Supermarket
ST-008,Bhubaneswar Superstore,East,Bhubaneswar,Express
ST-009,Ahmedabad Mart,West,Ahmedabad,Supermarket
ST-010,Indore Mart,Central,Indore,Supermarket
ST-011,Jaipur Mart,North,Jaipur,Convenience
ST-012,Hyderabad Superstore,South,Hyderabad,Supermarket
ST-013,Kolkata Superstore,East,Kolkata,Supermarket
ST-014,Pune Superstore,West,Pune,Convenience
ST-015,Nagpur Superstore,Central,Nagpur,Convenience`;

export const ordersRawCSV = `order_id,order_date,store_id,product_id,customer_id,sales_channel,units_sold,unit_price,discount_pct,payment_status,delivery_status
O-00001,2026-04-24,ST-005,P-009,C-0014,Online,3,208.95,0,Paid,Processing
O-00002,2026-03-23,ST-010,P-005,C-0027,Mobile App,6,49.0,20,Pending,Processing
O-00003,2026-02-12,ST-002,P-001,C-0055,In-store,5,359.1,0,Paid,Delivered
O-00004,2026-01-10,ST-009,P-008,C-0055,In-store,9,224.1,0,Paid,Processing
O-00005,2026-02-09,ST-009,P-010,C-0019,Mobile App,7,99.0,0,Paid,Processing
O-00006,2026-04-24,ST-011,P-004,C-0032,Partner,2,208.95,15,Paid,Delivered
O-00007,2026-04-05,ST-013,P-003,C-0023,Mobile App,7,539.1,0,Pending,Delivered
O-00008,2026-01-29,ST-003,P-005,C-0014,In-store,7,44.1,10,Pending,Processing
O-00009,2026-01-25,ST-014,P-005,C-0030,Partner,4,44.1,20,Paid,Processing
O-00010,2026-03-28,ST-013,P-002,C-0036,Mobile App,6,178.8,10,Paid,Delivered
O-00011,2026-03-18,ST-003,P-005,C-0075,Partner,5,44.1,0,Paid,Processing
O-00012,2026-01-25,ST-010,P-007,C-0066,Mobile App,2,438.9,15,Paid,Returned
O-00013,2026-01-09,ST-009,P-001,C-0069,Mobile App,4,418.95,10,Paid,Delivered
O-00014,2026-03-31,ST-009,P-005,C-0040,Mobile App,7,51.45,10,Paid,Delivered
O-00015,2026-02-08,ST-011,P-007,C-0049,Partner,3,478.8,15,Paid,Processing
O-00016,2026-02-26,ST-004,P-005,C-0056,In-store,6,53.9,10,Pending,Delivered
O-00017,2026-03-28,ST-005,P-002,C-0066,Mobile App,6,134.1,0,Paid,Delivered
O-00018,2026-04-19,ST-001,P-003,C-0006,Online,4,658.9,15,Pending,Returned
O-00019,2026-01-19,ST-004,P-010,C-0050,Online,8,108.9,0,Paid,Returned
O-00020,2026-02-01,ST-003,P-004,C-0067,Online,8,179.1,15,Pending,Delivered
O-00021,2026-04-07,ST-011,P-008,C-0068,Partner,9,298.8,5,Pending,Returned
O-00022,2026-04-18,ST-012,P-003,C-0061,Mobile App,8,628.95,0,Pending,Delivered
O-00023,2026-02-12,ST-008,P-005,C-0010,Mobile App,5,49.0,5,Paid,Delivered
O-00024,2026-02-23,ST-004,P-003,C-0050,Partner,3,599.0,0,Paid,Returned
O-00025,2026-03-31,ST-001,P-007,C-0027,Online,7,438.9,15,Pending,Returned
O-00026,2026-04-06,ST-006,P-001,C-0039,In-store,7,438.9,15,Pending,Delivered
O-00027,2026-03-27,ST-007,P-005,C-0063,Partner,1,53.9,5,Paid,Returned
O-00028,2026-03-14,ST-010,P-003,C-0069,Online,1,658.9,15,Paid,Returned
O-00029,2026-02-18,ST-014,P-003,C-0060,Mobile App,3,539.1,5,Paid,Returned
O-00030,2026-04-17,ST-006,P-006,C-0049,Online,5,108.9,5,Pending,Delivered
O-00031,2026-01-06,ST-001,P-009,C-0045,Online,4,179.1,20,Paid,Delivered
O-00032,2026-03-27,ST-010,P-001,C-0020,Online,4,399.0,10,Paid,Returned
O-00033,2026-04-06,ST-013,P-005,C-0048,Online,3,58.8,15,Paid,Processing
O-00034,2026-04-27,ST-010,P-002,C-0004,Partner,5,178.8,20,Pending,Delivered
O-00035,2026-03-18,ST-010,P-002,C-0032,Online,2,156.45,20,Paid,Processing
O-00036,2026-02-13,ST-007,P-009,C-0048,Online,2,238.8,20,Pending,Returned
O-00037,2026-01-23,ST-007,P-002,C-0047,Mobile App,8,149.0,10,Pending,Returned
O-00038,2026-04-17,ST-014,P-007,C-0076,Online,5,418.95,0,Paid,Returned
O-00039,2026-03-05,ST-013,P-004,C-0060,Mobile App,7,208.95,0,Paid,Returned
O-00040,2026-03-31,ST-006,P-004,C-0034,Mobile App,6,208.95,15,Paid,Delivered
O-00041,2026-03-30,ST-004,P-002,C-0053,Partner,8,178.8,0,Pending,Returned
O-00042,2026-02-01,ST-002,P-001,C-0038,Mobile App,4,438.9,20,Paid,Returned
O-00043,2026-02-15,ST-009,P-009,C-0045,Partner,7,238.8,5,Paid,Processing
O-00044,2026-04-06,ST-004,P-005,C-0016,In-store,4,51.45,0,Paid,Delivered
O-00045,2026-01-13,ST-005,P-008,C-0076,In-store,9,298.8,5,Paid,Delivered
O-00046,2026-02-05,ST-003,P-006,C-0039,Online,1,118.8,0,Paid,Processing
O-00047,2026-02-06,ST-011,P-003,C-0063,Partner,2,539.1,15,Pending,Returned
O-00048,2026-04-16,ST-003,P-006,C-0007,Online,5,108.9,0,Pending,Returned
O-00049,2026-02-08,ST-010,P-002,C-0007,Online,3,149.0,15,Paid,Delivered
O-00050,2026-02-27,ST-013,P-009,C-0054,Partner,4,238.8,10,Paid,Returned
O-00051,2026-01-13,ST-010,P-005,C-0080,In-store,1,58.8,20,Paid,Processing
O-00052,2026-01-21,ST-003,P-002,C-0031,Online,3,178.8,0,Pending,Returned
O-00053,2026-04-01,ST-008,P-010,C-0038,Mobile App,1,99.0,5,Pending,Delivered
O-00054,2026-03-11,ST-015,P-004,C-0034,In-store,4,218.9,0,Paid,Processing
O-00055,2026-04-06,ST-002,P-003,C-0008,Mobile App,3,628.95,15,Pending,Delivered
O-00056,2026-03-11,ST-012,P-008,C-0039,Partner,7,261.45,15,Pending,Delivered
O-00057,2026-01-04,ST-001,P-010,C-0056,Online,6,118.8,5,Paid,Delivered
O-00058,2026-03-25,ST-010,P-005,C-0006,Partner,3,53.9,15,Paid,Delivered
O-00059,2026-02-22,ST-007,P-010,C-0063,Mobile App,2,108.9,5,Paid,Delivered
O-00060,2026-02-21,ST-006,P-003,C-0053,Online,8,628.95,20,Pending,Delivered
O-00061,2026-04-16,ST-005,P-006,C-0042,Online,2,108.9,15,Pending,Returned
O-00062,2026-03-22,ST-004,P-001,C-0067,Partner,6,478.8,10,Paid,Delivered
O-00063,2026-03-04,ST-009,P-005,C-0017,Online,5,53.9,20,Paid,Delivered
O-00064,2026-01-12,ST-005,P-003,C-0071,In-store,1,718.8,10,Paid,Returned
O-00065,2026-04-01,ST-011,P-002,C-0020,Mobile App,8,156.45,15,Pending,Returned
O-00066,2026-01-25,ST-004,P-008,C-0059,In-store,9,249.0,10,Paid,Processing
O-00067,2026-04-03,ST-006,P-007,C-0065,Mobile App,5,359.1,5,Pending,Delivered
O-00068,2026-04-08,ST-009,P-008,C-0062,Partner,6,261.45,15,Pending,Processing
O-00069,2026-01-06,ST-012,P-004,C-0031,Mobile App,7,199.0,10,Pending,Returned
O-00070,2026-03-06,ST-011,P-007,C-0020,Mobile App,8,359.1,0,Paid,Returned
O-00071,2026-04-22,ST-009,P-002,C-0059,In-store,1,149.0,10,Paid,Returned
O-00072,2026-04-20,ST-006,P-005,C-0080,Partner,7,44.1,5,Paid,Returned
O-00073,2026-03-29,ST-001,P-009,C-0080,Mobile App,2,199.0,20,Paid,Delivered
O-00074,2026-02-08,ST-002,P-007,C-0013,Online,8,399.0,20,Paid,Processing
O-00075,2026-02-01,ST-005,P-001,C-0046,Partner,6,438.9,0,Paid,Delivered
O-00076,2026-01-31,ST-002,P-003,C-0079,Partner,7,718.8,20,Paid,Delivered
O-00077,2026-01-02,ST-011,P-008,C-0033,Partner,8,261.45,20,Paid,Delivered
O-00078,2026-02-02,ST-008,P-002,C-0045,Partner,5,163.9,20,Paid,Delivered
O-00079,2026-03-15,ST-014,P-007,C-0062,Mobile App,2,399.0,10,Paid,Processing
O-00080,2026-04-21,ST-014,P-001,C-0051,Online,5,359.1,15,Pending,Processing
O-00081,2026-02-02,ST-010,P-004,C-0046,In-store,4,199.0,15,Paid,Delivered
O-00082,2026-04-04,ST-013,P-005,C-0057,In-store,1,58.8,5,Paid,Processing
O-00083,2026-04-11,ST-012,P-006,C-0054,Mobile App,3,99.0,0,Paid,Delivered
O-00084,2026-03-01,ST-015,P-005,C-0062,Online,5,51.45,0,Paid,Delivered
O-00085,2026-01-02,ST-014,P-007,C-0072,Mobile App,6,359.1,10,Paid,Returned
O-00086,2026-03-28,ST-011,P-006,C-0034,In-store,7,103.95,0,Pending,Delivered
O-00087,2026-03-24,ST-015,P-010,C-0072,Online,6,118.8,0,Pending,Processing
O-00088,2026-03-05,ST-002,P-007,C-0018,Online,1,359.1,5,Paid,Delivered
O-00089,2026-04-06,ST-003,P-009,C-0050,Partner,8,208.95,20,Paid,Returned
O-00090,2026-03-30,ST-014,P-002,C-0063,Mobile App,7,156.45,0,Paid,Returned
O-00091,2026-04-26,ST-004,P-008,C-0047,Mobile App,2,261.45,15,Paid,Returned
O-00092,2026-01-28,ST-004,P-005,C-0016,Online,8,44.1,20,Paid,Processing
O-00093,2026-01-27,ST-003,P-004,C-0073,In-store,4,179.1,15,Paid,Processing
O-00094,2026-01-17,ST-013,P-003,C-0077,Mobile App,1,628.95,0,Paid,Delivered
O-00095,2026-02-11,ST-003,P-001,C-0002,Online,6,399.0,15,Paid,Processing
O-00096,2026-01-09,ST-003,P-001,C-0054,Partner,9,359.1,20,Pending,Processing
O-00097,2026-03-20,ST-010,P-009,C-0014,Online,8,238.8,0,Paid,Returned
O-00098,2026-01-14,ST-001,P-001,C-0062,Partner,7,438.9,20,Pending,Delivered
O-00099,2026-02-05,ST-006,P-002,C-0078,Mobile App,3,134.1,0,Pending,Processing
O-00100,2026-01-15,ST-009,P-008,C-0078,In-store,7,224.1,20,Pending,Returned
O-00101,2026-04-04,ST-007,P-004,C-0044,Online,8,218.9,10,Paid,Returned
O-00102,2026-04-29,ST-011,P-006,C-0033,Partner,6,99.0,20,Paid,Delivered
O-00103,2026-03-13,ST-002,P-002,C-0056,Online,2,156.45,0,Paid,Delivered
O-00104,2026-02-09,ST-006,P-007,C-0055,Mobile App,1,418.95,15,Paid,Delivered
O-00105,2026-04-19,ST-011,P-003,C-0062,Mobile App,4,539.1,5,Paid,Processing
O-00106,2026-03-28,ST-004,P-010,C-0055,Online,9,118.8,15,Paid,Delivered
O-00107,2026-01-24,ST-005,P-003,C-0040,In-store,6,628.95,0,Pending,Delivered
O-00108,2026-02-18,ST-012,P-003,C-0004,Partner,2,718.8,0,Pending,Processing
O-00109,2026-01-11,ST-006,P-003,C-0040,Online,6,718.8,15,Paid,Delivered
O-00110,2026-02-24,ST-001,P-010,C-0011,Partner,5,108.9,20,Pending,Returned
O-00111,2026-01-15,ST-004,P-005,C-0066,Mobile App,2,51.45,10,Pending,Processing
O-00112,2026-02-08,ST-004,P-001,C-0051,In-store,1,359.1,0,Paid,Processing
O-00113,2026-02-25,ST-006,P-005,C-0016,In-store,1,53.9,20,Paid,Returned
O-00114,2026-04-14,ST-012,P-009,C-0030,Mobile App,9,238.8,20,Paid,Returned
O-00115,2026-03-15,ST-007,P-001,C-0003,Partner,8,359.1,5,Pending,Returned
O-00116,2026-04-13,ST-002,P-005,C-0052,Partner,1,51.45,0,Paid,Delivered
O-00117,2026-02-21,ST-014,P-007,C-0014,Online,4,438.9,15,Pending,Processing
O-00118,2026-03-23,ST-004,P-006,C-0043,Online,3,89.1,15,Paid,Processing
O-00119,2026-02-02,ST-012,P-006,C-0019,In-store,4,89.1,0,Paid,Delivered
O-00120,2026-02-27,ST-003,P-002,C-0064,Mobile App,8,178.8,15,Paid,Delivered
O-00121,2026-03-17,ST-002,P-008,C-0061,Online,8,261.45,5,Paid,Delivered
O-00122,2026-04-17,ST-008,P-005,C-0058,Mobile App,1,44.1,5,Paid,Delivered
O-00123,2026-03-12,ST-010,P-010,C-0065,Online,7,108.9,15,Pending,Delivered
O-00124,2026-02-27,ST-010,P-006,C-0061,Online,9,99.0,0,Paid,Delivered
O-00125,2026-02-26,ST-011,P-009,C-0023,Partner,1,199.0,20,Paid,Processing
O-00126,2026-03-28,ST-015,P-006,C-0037,Online,7,108.9,5,Paid,Delivered
O-00127,2026-04-03,ST-002,P-006,C-0072,In-store,7,103.95,5,Paid,Delivered
O-00128,2026-03-31,ST-011,P-010,C-0019,Partner,6,103.95,20,Paid,Delivered
O-00129,2026-03-31,ST-009,P-005,C-0049,Online,6,49.0,20,Pending,Processing
O-00130,2026-04-09,ST-006,P-001,C-0040,Partner,3,399.0,5,Paid,Delivered
O-00131,2026-04-09,ST-003,P-003,C-0010,Online,5,539.1,15,Paid,Delivered
O-00132,2026-04-09,ST-007,P-010,C-0020,In-store,3,99.0,20,Pending,Delivered
O-00133,2026-04-07,ST-006,P-007,C-0031,Partner,8,478.8,5,Paid,Delivered
O-00134,2026-03-15,ST-013,P-005,C-0061,Partner,4,51.45,20,Pending,Processing
O-00135,2026-04-13,ST-009,P-007,C-0068,In-store,7,399.0,0,Paid,Delivered
O-00136,2026-04-19,ST-014,P-008,C-0048,Online,9,224.1,20,Paid,Delivered
O-00137,2026-01-12,ST-005,P-003,C-0058,In-store,9,599.0,10,Pending,Processing
O-00138,2026-01-31,ST-007,P-001,C-0007,Partner,7,478.8,5,Paid,Processing
O-00139,2026-01-18,ST-001,P-004,C-0041,Online,2,208.95,0,Paid,Returned
O-00140,2026-04-26,ST-013,P-003,C-0061,Online,8,718.8,0,Paid,Processing
O-00141,2026-02-24,ST-014,P-004,C-0020,Online,9,238.8,15,Paid,Delivered
O-00142,2026-04-12,ST-002,P-005,C-0007,Partner,4,53.9,20,Paid,Delivered
O-00143,2026-01-31,ST-010,P-008,C-0069,In-store,1,298.8,15,Paid,Returned
O-00144,2026-01-24,ST-010,P-001,C-0046,Online,4,478.8,10,Paid,Delivered
O-00145,2026-02-19,ST-009,P-009,C-0065,Partner,9,238.8,0,Paid,Returned
O-00146,2026-01-31,ST-005,P-006,C-0003,Online,6,89.1,5,Paid,Delivered
O-00147,2026-03-01,ST-006,P-001,C-0070,Partner,6,399.0,20,Paid,Delivered
O-00148,2026-01-06,ST-012,P-002,C-0059,In-store,1,156.45,0,Paid,Processing
O-00149,2026-01-05,ST-009,P-005,C-0051,In-store,9,53.9,5,Paid,Processing
O-00150,2026-02-25,ST-014,P-001,C-0043,Partner,5,359.1,5,Pending,Returned
O-00151,2026-02-04,ST-003,P-006,C-0064,Online,8,103.95,15,Pending,Delivered
O-00152,2026-01-14,ST-010,P-007,C-0024,Online,9,418.95,5,Paid,Processing
O-00153,2026-02-26,ST-008,P-005,C-0078,Mobile App,7,49.0,20,Pending,Delivered
O-00154,2026-03-27,ST-010,P-006,C-0056,Partner,5,89.1,0,Paid,Delivered
O-00155,2026-01-09,ST-003,P-001,C-0078,In-store,8,359.1,0,Paid,Processing
O-00156,2026-02-17,ST-010,P-007,C-0005,Partner,3,438.9,5,Paid,Delivered
O-00157,2026-01-15,ST-006,P-009,C-0051,Online,6,208.95,0,Paid,Returned
O-00158,2026-04-01,ST-007,P-009,C-0072,Partner,2,208.95,5,Paid,Processing
O-00159,2026-01-23,ST-004,P-008,C-0016,Partner,3,224.1,10,Paid,Processing
O-00160,2026-04-25,ST-012,P-006,C-0009,Mobile App,9,118.8,5,Paid,Delivered
O-00161,2026-01-31,ST-009,P-006,C-0029,Partner,2,99.0,0,Paid,Processing
O-00162,2026-03-20,ST-010,P-009,C-0048,Online,8,238.8,0,Paid,Processing
O-00163,2026-04-16,ST-012,P-007,C-0062,Online,9,438.9,10,Paid,Processing
O-00164,2026-04-23,ST-008,P-002,C-0060,In-store,9,156.45,0,Paid,Returned
O-00165,2026-02-08,ST-015,P-009,C-0008,In-store,2,238.8,0,Paid,Processing
O-00166,2026-01-26,ST-006,P-004,C-0067,Mobile App,5,179.1,5,Paid,Processing
O-00167,2026-03-16,ST-009,P-010,C-0012,In-store,9,99.0,15,Paid,Processing
O-00168,2026-04-09,ST-001,P-010,C-0004,Mobile App,2,89.1,20,Paid,Returned
O-00169,2026-03-24,ST-011,P-010,C-0004,Mobile App,8,118.8,5,Pending,Delivered
O-00170,2026-02-26,ST-005,P-007,C-0059,Partner,2,359.1,0,Pending,Returned
O-00171,2026-02-10,ST-006,P-004,C-0078,Mobile App,3,208.95,20,Pending,Delivered
O-00172,2026-03-01,ST-009,P-006,C-0072,Online,2,103.95,0,Paid,Returned
O-00173,2026-04-21,ST-003,P-004,C-0013,Partner,1,208.95,10,Paid,Delivered
O-00174,2026-03-05,ST-015,P-006,C-0074,Partner,6,99.0,0,Pending,Processing
O-00175,2026-01-31,ST-001,P-008,C-0012,In-store,7,298.8,10,Paid,Delivered
O-00176,2026-01-02,ST-005,P-001,C-0064,Online,8,418.95,15,Pending,Delivered
O-00177,2026-02-21,ST-012,P-005,C-0047,Online,7,51.45,0,Paid,Processing
O-00178,2026-04-08,ST-005,P-009,C-0010,Mobile App,7,238.8,10,Paid,Delivered
O-00179,2026-04-07,ST-007,P-002,C-0048,In-store,6,178.8,5,Paid,Returned
O-00180,2026-02-12,ST-001,P-009,C-0006,Partner,1,199.0,20,Pending,Delivered
O-00181,2026-02-10,ST-015,P-010,C-0066,In-store,3,103.95,15,Pending,Processing
O-00182,2026-04-01,ST-006,P-010,C-0065,Mobile App,9,118.8,10,Pending,Delivered
O-00183,2026-04-12,ST-006,P-006,C-0015,Online,7,118.8,5,Pending,Processing
O-00184,2026-01-22,ST-010,P-010,C-0030,Partner,1,118.8,10,Paid,Delivered
O-00185,2026-02-10,ST-010,P-001,C-0015,Partner,4,359.1,10,Paid,Returned
O-00186,2026-01-18,ST-007,P-004,C-0065,In-store,8,179.1,20,Paid,Returned
O-00187,2026-02-13,ST-007,P-009,C-0041,Mobile App,3,218.9,15,Paid,Returned
O-00188,2026-02-08,ST-004,P-004,C-0036,Mobile App,9,208.95,0,Paid,Returned
O-00189,2026-01-16,ST-008,P-006,C-0045,Partner,9,103.95,5,Pending,Processing
O-00190,2026-04-29,ST-005,P-003,C-0006,Partner,5,539.1,5,Paid,Returned
O-00191,2026-02-04,ST-004,P-004,C-0069,In-store,5,238.8,20,Paid,Delivered
O-00192,2026-01-13,ST-001,P-004,C-0068,Partner,4,199.0,0,Paid,Returned
O-00193,2026-02-22,ST-011,P-002,C-0018,Partner,1,178.8,0,Pending,Delivered
O-00194,2026-03-15,ST-006,P-005,C-0037,In-store,1,44.1,20,Paid,Delivered
O-00195,2026-01-24,ST-015,P-007,C-0023,Mobile App,1,438.9,10,Paid,Delivered
O-00196,2026-02-28,ST-010,P-005,C-0078,Partner,2,51.45,5,Paid,Returned
O-00197,2026-02-28,ST-004,P-005,C-0015,Mobile App,6,49.0,20,Paid,Delivered
O-00198,2026-04-20,ST-013,P-006,C-0038,Partner,4,99.0,15,Pending,Processing
O-00199,2026-02-11,ST-007,P-002,C-0013,In-store,3,149.0,10,Paid,Processing
O-00200,2026-03-16,ST-004,P-007,C-0058,Online,5,418.95,5,Paid,Processing
O-00201,2026-02-21,ST-001,P-004,C-0016,Mobile App,8,208.95,0,Paid,Processing
O-00202,2026-01-20,ST-010,P-006,C-0029,Partner,4,99.0,10,Paid,Returned
O-00203,2026-03-29,ST-015,P-009,C-0061,Online,9,199.0,0,Pending,Processing
O-00204,2026-04-26,ST-015,P-002,C-0073,In-store,2,134.1,15,Paid,Delivered
O-00205,2026-01-27,ST-014,P-006,C-0067,Partner,8,89.1,20,Paid,Returned
O-00206,2026-03-14,ST-008,P-001,C-0017,Online,9,438.9,10,Pending,Processing
O-00207,2026-01-10,ST-007,P-001,C-0033,Online,1,399.0,15,Pending,Processing
O-00208,2026-02-06,ST-009,P-002,C-0008,Partner,2,163.9,0,Paid,Delivered
O-00209,2026-01-11,ST-006,P-007,C-0049,In-store,8,438.9,10,Paid,Delivered
O-00210,2026-01-29,ST-009,P-003,C-0051,Online,9,599.0,20,Paid,Processing
O-00211,2026-04-16,ST-011,P-008,C-0070,In-store,7,298.8,10,Paid,Returned
O-00212,2026-04-14,ST-003,P-006,C-0036,Partner,4,89.1,0,Paid,Delivered
O-00213,2026-03-28,ST-002,P-004,C-0013,Online,1,218.9,15,Paid,Delivered
O-00214,2026-01-18,ST-008,P-007,C-0030,Mobile App,9,399.0,0,Paid,Processing
O-00215,2026-03-26,ST-010,P-010,C-0042,In-store,4,103.95,0,Pending,Processing
O-00216,2026-03-05,ST-001,P-005,C-0072,Online,3,53.9,15,Paid,Returned
O-00217,2026-02-18,ST-006,P-009,C-0054,In-store,7,199.0,5,Pending,Delivered
O-00218,2026-02-22,ST-005,P-004,C-0019,Partner,8,179.1,15,Paid,Returned
O-00219,2026-04-19,ST-005,P-004,C-0027,Mobile App,6,179.1,10,Paid,Delivered
O-00220,2026-04-13,ST-005,P-001,C-0049,In-store,1,359.1,0,Pending,Delivered
O-00221,2026-01-16,ST-005,P-006,C-0002,Partner,4,99.0,20,Paid,Delivered
O-00222,2026-02-18,ST-015,P-007,C-0031,Partner,9,418.95,5,Paid,Processing
O-00223,2026-04-13,ST-006,P-005,C-0066,Partner,8,53.9,0,Paid,Delivered
O-00224,2026-04-05,ST-006,P-006,C-0053,In-store,1,118.8,0,Paid,Processing
O-00225,2026-01-26,ST-015,P-009,C-0075,Mobile App,7,208.95,0,Paid,Returned
O-00226,2026-03-29,ST-014,P-010,C-0032,Mobile App,8,118.8,20,Paid,Returned
O-00227,2026-04-03,ST-008,P-008,C-0022,Partner,6,249.0,0,Paid,Delivered
O-00228,2026-01-18,ST-001,P-009,C-0010,In-store,1,179.1,10,Paid,Delivered
O-00229,2026-03-21,ST-004,P-001,C-0065,Partner,8,418.95,0,Pending,Delivered
O-00230,2026-03-09,ST-009,P-001,C-0071,Mobile App,7,359.1,0,Paid,Delivered
O-00231,2026-03-09,ST-014,P-009,C-0056,In-store,3,179.1,0,Paid,Delivered
O-00232,2026-01-11,ST-009,P-010,C-0033,Mobile App,6,103.95,10,Pending,Returned
O-00233,2026-04-20,ST-004,P-010,C-0029,Online,5,89.1,20,Paid,Returned
O-00234,2026-01-02,ST-007,P-007,C-0071,In-store,8,359.1,20,Paid,Returned
O-00235,2026-01-30,ST-011,P-007,C-0043,In-store,2,478.8,0,Pending,Processing
O-00236,2026-03-26,ST-015,P-001,C-0010,Online,5,478.8,15,Paid,Processing
O-00237,2026-02-08,ST-004,P-001,C-0076,In-store,3,438.9,0,Paid,Returned
O-00238,2026-04-06,ST-006,P-009,C-0050,Mobile App,3,179.1,15,Paid,Delivered
O-00239,2026-03-18,ST-004,P-007,C-0010,Partner,6,478.8,15,Paid,Delivered
O-00240,2026-03-12,ST-013,P-005,C-0058,Partner,8,49.0,5,Pending,Delivered
O-00241,2026-04-13,ST-011,P-010,C-0049,In-store,2,118.8,5,Paid,Delivered
O-00242,2026-02-16,ST-003,P-005,C-0049,Online,3,53.9,5,Paid,Delivered
O-00243,2026-01-12,ST-008,P-005,C-0047,In-store,5,44.1,0,Pending,Returned
O-00244,2026-01-12,ST-009,P-009,C-0066,Mobile App,7,179.1,0,Paid,Processing
O-00245,2026-04-03,ST-001,P-007,C-0038,In-store,7,438.9,0,Paid,Returned
O-00246,2026-01-19,ST-003,P-003,C-0035,Online,5,628.95,10,Paid,Returned
O-00247,2026-02-02,ST-007,P-005,C-0039,In-store,8,44.1,5,Pending,Delivered
O-00248,2026-02-12,ST-002,P-008,C-0018,Partner,5,224.1,10,Paid,Returned
O-00249,2026-03-19,ST-007,P-006,C-0077,In-store,3,103.95,5,Pending,Processing
O-00250,2026-04-11,ST-007,P-003,C-0041,In-store,5,658.9,15,Paid,Returned
O-00251,2026-01-26,ST-014,P-005,C-0051,In-store,6,44.1,15,Paid,Returned
O-00252,2026-03-05,ST-008,P-004,C-0038,In-store,2,218.9,20,Paid,Delivered
O-00253,2026-02-27,ST-011,P-005,C-0020,Partner,7,53.9,0,Pending,Returned
O-00254,2026-04-28,ST-001,P-009,C-0047,Online,9,238.8,20,Paid,Delivered
O-00255,2026-03-28,ST-003,P-006,C-0079,Partner,1,118.8,20,Paid,Returned
O-00256,2026-04-06,ST-001,P-002,C-0013,In-store,5,149.0,15,Pending,Processing
O-00257,2026-01-04,ST-008,P-007,C-0076,Partner,9,399.0,5,Paid,Processing
O-00258,2026-02-09,ST-015,P-007,C-0011,Mobile App,2,399.0,5,Pending,Delivered
O-00259,2026-04-03,ST-008,P-009,C-0045,Partner,8,179.1,10,Paid,Delivered
O-00260,2026-01-14,ST-001,P-005,C-0015,In-store,1,51.45,20,Paid,Delivered
O-00261,2026-01-30,ST-003,P-009,C-0043,Partner,9,218.9,10,Paid,Delivered
O-00262,2026-02-24,ST-007,P-007,C-0004,Partner,4,438.9,15,Paid,Delivered
O-00263,2026-02-16,ST-005,P-004,C-0009,Mobile App,2,238.8,0,Paid,Returned
O-00264,2026-02-19,ST-005,P-002,C-0063,Partner,9,156.45,15,Paid,Processing
O-00265,2026-03-17,ST-014,P-006,C-0059,Online,3,103.95,15,Paid,Processing
O-00266,2026-03-30,ST-004,P-002,C-0040,In-store,2,149.0,5,Pending,Returned
O-00267,2026-03-04,ST-003,P-010,C-0074,In-store,7,108.9,0,Paid,Returned
O-00268,2026-01-07,ST-003,P-005,C-0024,Mobile App,6,53.9,15,Paid,Returned
O-00269,2026-03-05,ST-004,P-003,C-0050,Partner,9,718.8,20,Pending,Returned
O-00270,2026-04-12,ST-008,P-008,C-0022,In-store,2,298.8,0,Paid,Delivered
O-00271,2026-03-14,ST-004,P-005,C-0069,Partner,5,49.0,10,Paid,Delivered
O-00272,2026-04-08,ST-013,P-005,C-0070,Partner,6,58.8,0,Paid,Returned
O-00273,2026-02-03,ST-012,P-002,C-0032,Mobile App,5,134.1,10,Paid,Returned
O-00274,2026-02-14,ST-013,P-002,C-0031,Partner,4,178.8,20,Paid,Delivered
O-00275,2026-03-10,ST-014,P-004,C-0027,Mobile App,1,238.8,5,Paid,Processing
O-00276,2026-04-15,ST-005,P-005,C-0074,Online,5,58.8,20,Paid,Returned
O-00277,2026-04-02,ST-005,P-001,C-0017,Mobile App,3,399.0,0,Paid,Returned
O-00278,2026-02-27,ST-003,P-008,C-0074,Online,5,273.9,10,Paid,Returned
O-00279,2026-02-11,ST-012,P-009,C-0036,Online,6,218.9,10,Paid,Returned
O-00280,2026-02-24,ST-014,P-006,C-0009,In-store,9,108.9,0,Pending,Processing
O-00281,2026-01-17,ST-014,P-006,C-0037,Partner,6,118.8,15,Paid,Delivered
O-00282,2026-02-26,ST-002,P-001,C-0059,Partner,1,359.1,0,Paid,Returned
O-00283,2026-01-12,ST-012,P-004,C-0017,Mobile App,5,199.0,5,Paid,Delivered
O-00284,2026-02-09,ST-011,P-006,C-0022,In-store,1,108.9,20,Pending,Delivered
O-00285,2026-03-17,ST-001,P-002,C-0028,In-store,8,134.1,0,Pending,Delivered
O-00286,2026-01-17,ST-012,P-001,C-0044,Partner,2,438.9,20,Paid,Delivered
O-00287,2026-04-23,ST-002,P-007,C-0014,Mobile App,2,418.95,5,Paid,Returned
O-00288,2026-01-02,ST-011,P-003,C-0019,In-store,2,718.8,15,Pending,Processing
O-00289,2026-02-26,ST-011,P-004,C-0020,In-store,7,238.8,20,Paid,Delivered
O-00290,2026-02-10,ST-013,P-003,C-0016,In-store,7,628.95,10,Paid,Processing
O-00291,2026-04-23,ST-004,P-002,C-0071,Mobile App,5,134.1,20,Paid,Delivered
O-00292,2026-01-15,ST-005,P-007,C-0007,In-store,4,438.9,10,Pending,Delivered
O-00293,2026-02-19,ST-015,P-009,C-0002,Partner,6,208.95,0,Paid,Delivered
O-00294,2026-01-02,ST-013,P-008,C-0010,Mobile App,1,298.8,0,Paid,Delivered
O-00295,2026-04-02,ST-013,P-001,C-0051,Partner,9,418.95,20,Pending,Returned
O-00296,2026-02-05,ST-011,P-002,C-0069,Online,9,178.8,0,Paid,Delivered
O-00297,2026-02-20,ST-015,P-009,C-0027,Online,3,238.8,5,Paid,Returned
O-00298,2026-02-28,ST-001,P-004,C-0032,Online,2,218.9,0,Paid,Delivered
O-00299,2026-02-14,ST-001,P-002,C-0018,Mobile App,1,149.0,10,Paid,Processing
O-00300,2026-04-14,ST-012,P-003,C-0035,Partner,2,539.1,5,Paid,Delivered
O-00301,2026-03-07,ST-012,P-005,C-0074,Mobile App,2,53.9,10,Paid,Returned
O-00302,2026-04-25,ST-003,P-010,C-0048,Online,3,103.95,0,Paid,Delivered
O-00303,2026-02-16,ST-014,P-001,C-0002,Partner,4,359.1,10,Paid,Delivered
O-00304,2026-02-23,ST-009,P-001,C-0054,Mobile App,4,418.95,0,Paid,Delivered
O-00305,2026-01-29,ST-006,P-010,C-0016,Online,9,89.1,0,Pending,Delivered
O-00306,2026-03-12,ST-014,P-008,C-0037,Partner,5,261.45,0,Paid,Processing
O-00307,2026-03-01,ST-005,P-004,C-0073,Mobile App,5,238.8,0,Pending,Delivered
O-00308,2026-01-04,ST-013,P-009,C-0032,In-store,3,179.1,10,Paid,Delivered
O-00309,2026-03-09,ST-001,P-006,C-0049,In-store,5,89.1,0,Pending,Returned
O-00310,2026-04-25,ST-003,P-001,C-0036,Partner,2,359.1,0,Paid,Returned
O-00311,2026-04-15,ST-010,P-002,C-0013,Partner,9,149.0,20,Paid,Delivered
O-00312,2026-04-19,ST-011,P-007,C-0017,Mobile App,4,418.95,5,Pending,Processing
O-00313,2026-01-18,ST-008,P-006,C-0035,Online,4,89.1,0,Paid,Delivered
O-00314,2026-03-10,ST-008,P-003,C-0060,Mobile App,6,658.9,0,Paid,Returned
O-00315,2026-04-14,ST-008,P-005,C-0034,Mobile App,2,44.1,0,Paid,Delivered
O-00316,2026-03-07,ST-003,P-006,C-0012,Online,4,103.95,10,Paid,Processing
O-00317,2026-03-12,ST-001,P-003,C-0052,In-store,8,718.8,20,Paid,Returned
O-00318,2026-04-17,ST-013,P-002,C-0018,In-store,2,134.1,0,Paid,Delivered
O-00319,2026-01-09,ST-006,P-007,C-0011,In-store,5,359.1,0,Pending,Delivered
O-00320,2026-01-07,ST-015,P-002,C-0043,In-store,2,134.1,10,Pending,Returned
O-00321,2026-01-28,ST-001,P-008,C-0049,In-store,7,249.0,5,Paid,Processing
O-00322,2026-03-20,ST-015,P-008,C-0020,In-store,1,298.8,15,Paid,Returned
O-00323,2026-02-05,ST-015,P-007,C-0071,Partner,8,359.1,0,Paid,Returned
O-00324,2026-02-18,ST-011,P-004,C-0068,Mobile App,4,238.8,0,Pending,Returned
O-00325,2026-02-04,ST-015,P-006,C-0073,In-store,9,103.95,10,Paid,Processing
O-00326,2026-03-09,ST-004,P-010,C-0004,Mobile App,5,89.1,10,Paid,Delivered
O-00327,2026-01-08,ST-004,P-002,C-0031,In-store,5,178.8,20,Pending,Processing
O-00328,2026-01-04,ST-003,P-003,C-0031,Mobile App,6,628.95,15,Paid,Delivered
O-00329,2026-01-12,ST-009,P-008,C-0040,Online,3,273.9,0,Paid,Delivered
O-00330,2026-01-26,ST-009,P-001,C-0062,In-store,1,418.95,15,Paid,Delivered
O-00331,2026-04-28,ST-001,P-006,C-0003,In-store,3,118.8,20,Paid,Processing
O-00332,2026-02-11,ST-006,P-002,C-0051,In-store,2,156.45,5,Paid,Returned
O-00333,2026-04-24,ST-011,P-008,C-0041,Mobile App,3,298.8,20,Paid,Delivered
O-00334,2026-01-01,ST-005,P-007,C-0038,Partner,3,399.0,20,Paid,Delivered
O-00335,2026-04-30,ST-006,P-010,C-0079,Partner,4,118.8,0,Paid,Processing
O-00336,2026-04-24,ST-004,P-002,C-0045,Online,6,149.0,20,Paid,Returned
O-00337,2026-02-02,ST-005,P-001,C-0027,Online,4,359.1,5,Paid,Delivered
O-00338,2026-04-23,ST-008,P-007,C-0054,Partner,3,438.9,10,Paid,Returned
O-00339,2026-01-10,ST-014,P-002,C-0062,Online,4,149.0,10,Paid,Delivered
O-00340,2026-04-24,ST-005,P-006,C-0014,Partner,2,103.95,0,Paid,Delivered
O-00341,2026-04-25,ST-015,P-009,C-0012,Partner,6,238.8,15,Paid,Returned
O-00342,2026-02-12,ST-010,P-003,C-0056,In-store,3,539.1,0,Paid,Returned
O-00343,2026-01-31,ST-012,P-009,C-0070,Online,5,208.95,5,Paid,Returned
O-00344,2026-01-01,ST-009,P-010,C-0063,Partner,3,89.1,5,Paid,Processing
O-00345,2026-01-22,ST-008,P-010,C-0026,Mobile App,2,89.1,0,Paid,Returned
O-00346,2026-02-03,ST-005,P-002,C-0051,Online,8,163.9,20,Pending,Delivered
O-00347,2026-01-06,ST-015,P-006,C-0049,Mobile App,6,99.0,10,Pending,Returned
O-00348,2026-03-27,ST-004,P-005,C-0035,Online,1,49.0,20,Paid,Processing
O-00349,2026-04-18,ST-007,P-009,C-0076,Partner,4,238.8,0,Pending,Returned
O-00350,2026-02-20,ST-015,P-010,C-0031,Online,8,103.95,0,Paid,Delivered
O-00351,2026-01-06,ST-003,P-008,C-0022,Partner,4,249.0,0,Paid,Returned
O-00352,2026-04-28,ST-014,P-004,C-0019,Online,5,208.95,20,Paid,Returned
O-00353,2026-02-28,ST-007,P-009,C-0071,Online,6,208.95,15,Pending,Delivered
O-00354,2026-04-10,ST-003,P-007,C-0019,Online,2,359.1,15,Paid,Processing
O-00355,2026-03-02,ST-005,P-007,C-0050,Online,8,478.8,15,Paid,Processing
O-00356,2026-04-24,ST-003,P-007,C-0080,Mobile App,7,359.1,10,Paid,Delivered
O-00357,2026-04-15,ST-015,P-008,C-0035,Mobile App,6,224.1,5,Paid,Processing
O-00358,2026-04-06,ST-014,P-008,C-0013,Partner,4,249.0,5,Paid,Processing
O-00359,2026-04-27,ST-010,P-007,C-0012,Partner,4,438.9,0,Pending,Processing
O-00360,2026-03-06,ST-009,P-001,C-0021,Partner,2,418.95,20,Paid,Delivered`;

function parseCSV<T>(csv: string, transformNumFields: string[] = []): T[] {
  const lines = csv.trim().split('\n');
  const headers = lines[0].split(',').map((h) => h.trim());
  const rows: T[] = [];

  for (let i = 1; i < lines.length; i++) {
    const values = lines[i].split(',').map((v) => v.trim());
    if (values.length !== headers.length) continue;
    const obj: Record<string, unknown> = {};
    headers.forEach((header, index) => {
      let val: string | number = values[index];
      if (transformNumFields.includes(header)) {
        val = Number(val);
      }
      obj[header] = val;
    });
    rows.push(obj as unknown as T);
  }
  return rows;
}

export const customers: Customer[] = parseCSV<Customer>(customersRawCSV);
export const products: Product[] = parseCSV<Product>(productsRawCSV, ['base_price']);
export const returnsData: ReturnRecord[] = parseCSV<ReturnRecord>(returnsRawCSV);
export const stores: Store[] = parseCSV<Store>(storesRawCSV);
export const orders: Order[] = parseCSV<Order>(ordersRawCSV, ['units_sold', 'unit_price', 'discount_pct']);
